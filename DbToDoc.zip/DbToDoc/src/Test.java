import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

import com.adp.dao.jdbc;
import com.adp.entities.KPI;
import com.adp.entities.KPI_DataLineage;
import com.adp.entities.KPI_Filters_Views;

public class Test {

	//public XWPFDocument document=null;
	public static XWPFRun run1=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			XWPFDocument document =new XWPFDocument();
			FileOutputStream out=new FileOutputStream(new File("C:\\Users\\BachuAka\\Desktop\\KPI.docx"));
			List<KPI> res=new jdbc().getData();
			
			List<String> headings=new ArrayList();
			headings.add("KPI Name");
			headings.add("KPI Description");
			headings.add("KPI Key");
			headings.add("Functional Area");
			headings.add("Formula Text");
			headings.add("Business Value");
			headings.add("Business Rule");
			headings.add("Benchmark Applicable");
			headings.add("Threshold Applicable");
			headings.add("Data Lineage Table");
			
			//int k=0;
			for(int k=0;k<res.size();k++){
				setTemplate(document,headings.get(0)+": ",true);
				setTemplate(document,res.get(k).getKpi_nm(),false);
				
				
				setTemplate(document,headings.get(1)+": ",true);
				setTemplate(document,(res.get(k).getKpi_dsc()!=null)?res.get(k).getKpi_dsc().replaceAll("<br>", " "):"",false);
				
				setTemplate(document,headings.get(2)+": ",true);
				setTemplate(document,res.get(k).getKpi_ky()+"",false);
				
				setTemplate(document,headings.get(3)+": ",true);
				setTemplate(document,res.get(k).getFuncl_area(),false);
				
				setTemplate(document,headings.get(4)+": ",true);
				setTemplate(document,res.get(k).getFrmul_txt(),false);
				
				setTemplate(document,headings.get(5)+": ",true);
				setTemplate(document,(res.get(k).getBus_val()!=null)?res.get(k).getBus_val().replaceAll("<br>", " "):"",false);
				
				setTemplate(document,headings.get(6)+": ",true);
				setTemplate(document,(res.get(k).getBus_rule()!=null)?res.get(k).getBus_val().replaceAll("<br>", " "):"",false);
				
				setTemplate(document,headings.get(7)+": ",true);
				setTemplate(document,(res.get(k).getBnchmrks_appl()!=null)?
						res.get(k).getBnchmrks_appl().replaceAll("<br>", " ").replaceAll("<li>", " ")
						.replaceAll("</li>", " ").replaceAll("<ul>", " ").replaceAll("</ul>", " "):"",false);
				
				setTemplate(document,headings.get(8)+": ",true);
				setTemplate(document,res.get(k).getTrshld_appl(),false);
				
				setTemplate(document,"Hover Text:",true);
				
				
				setTemplate(document,"Data Source: ",true);
				List<KPI_DataLineage> resLi=new jdbc().getDataLineage(res.get(k).getKpi_ky());
				if(resLi.size()!=0){
					
					XWPFTable table=document.createTable();
					XWPFTableRow row1=table.getRow(0);
					row1.getCell(0).setText("Context Name");
					row1.addNewTableCell().setText("Data Source");
					row1.addNewTableCell().setText("Data Logic");
					for(int i=0;i<3;i++){
						row1.getCell(i).setColor("7f8c8d");
					}
					
				
					int j=0;
					for(int i=0;i<resLi.size();i++){
						XWPFTableRow row=table.createRow();
						row.getCell(j++).setText(resLi.get(i).getContx_nm());
						row.getCell(j++).setText((resLi.get(i).getData_lineage()!=null)?resLi.get(i).getData_lineage().replaceAll("<br>", " "):" ");
						if(resLi.get(i).getKpi_defn()!=null)
						row.getCell(j++).setText(resLi.get(i).getKpi_defn().replaceAll("<br>", " "));
						else{
							row.getCell(j++).setText("");
						}
						//System.out.println(resLi.get(i).getKpi_defn().replaceAll("<br>", " "));
						j=0;
					}
				}
			
				
				List<KPI_Filters_Views> filterViewBy=new jdbc().getFitersViews(res.get(k).getKpi_ky());
				//System.out.println(filterViewBy.size());
				if(filterViewBy!=null){
					setTemplate(document,"Filters: ",true);
					StringBuilder fil=new StringBuilder();
					for(int i=0;i<filterViewBy.size();i++){
						if(filterViewBy.get(i).getFilter().equals("Y")){
							fil.append(filterViewBy.get(i).getContx_nm()+",");
						}
						
					}
					/*if(fil!=null)
					//fil.setCharAt(fil.length()-1, '.');
					fil.replace(fil.length()-1, fil.length()-1, ".");*/
					setTemplate(document,fil.toString().replaceAll("Filter By", ""),false);
					setTemplate(document,"ViewBy: ",true);
					
					
					StringBuilder view=new StringBuilder();
					for(int i=0;i<filterViewBy.size();i++){
						if(filterViewBy.get(i).getViewBy().equals("Y")){
							view.append(filterViewBy.get(i).getContx_nm()+",");
						}
						
					}
					/*if(view!=null)
					view.setCharAt(view.length()-1, '.');*/
					setTemplate(document,view.toString(),false);
				}
				run1.addBreak(BreakType.PAGE);
		}
			
			document.write(out);
			out.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Success");
	}

	public static void setTemplate(XWPFDocument document,String value,boolean bold){
		
		XWPFParagraph paragraph1=document.createParagraph();
		run1=paragraph1.createRun();
		run1.setText(value);
		run1.setBold(bold);
	}
}
