package com.adp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.adp.entities.KPI;
import com.adp.entities.KPI_DataLineage;
import com.adp.entities.KPI_Default_ViewBy;
import com.adp.entities.KPI_Filters_Views;

public class jdbc {

	public static int domain=0;
	public List<KPI> getData(int src){
		Connection con=null;
		domain=src;
		List<KPI> resList=new ArrayList();
		try{
			
			con=getConnection();
			Statement st=con.createStatement();
			/*ResultSet rs=st.executeQuery("select * from T_KPI_INFO where LANG_CD='en_US' and kpi_ky=60 and srce_sys_nm='Vantage'");*/
			ResultSet rs=null;
			switch(src){
			case 1: 
				rs=st.executeQuery("select * from T_KPI_INFO where LANG_CD='en_US' and srce_sys_nm='Vantage'");
				break;
			case 2:
				rs=st.executeQuery("select * from T_KPI_INFO where LANG_CD='en_US' and srce_sys_nm='WFN'");
				break;
			case 3:
				rs=st.executeQuery("select * from T_KPI_INFO where LANG_CD='en_US' and srce_sys_nm='EV5'");
				break;
			case 4:
				rs=st.executeQuery("select * from T_KPI_INFO where LANG_CD='fr_CA' and srce_sys_nm='WFN'");
				break;
			}
			
			//ResultSet rs=st.executeQuery("select * from T_KPI_INFO where LANG_CD='en_US' and srce_sys_nm='Vantage'");
			while(rs.next()){
				resList.add(new KPI(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4)
						,rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9)
						,rs.getString(10),rs.getString(11),rs.getString(12),rs.getString(13),rs.getInt(14),
						rs.getString(15),rs.getInt(16)));
	            }
			rs.close();
		}catch(ClassNotFoundException e1){
			System.out.println(e1);
		}
		catch(SQLException e1){
			e1.printStackTrace();
		}
		finally{
			try{
				con.close();
			}catch(Exception e2){}
		}
		
		return resList;
	}
	
	
	
	public List<KPI_DataLineage> getDataLineage(int kpi_ky){
		Connection con=null;
		List<KPI_DataLineage> resList1=new ArrayList();
		try{
			
			con=getConnection();
			Statement st=con.createStatement();
			
				ResultSet rs=null;//=st.executeQuery("select contx_nm,data_lineage,kpi_defn,dflt_data_lineage_ind from t_KPI_data_lineage where kpi_ky=" + kpi_ky + " and srce_sys_nm='Vantage' and lang_cd='en_US'");
				switch(domain){
				case 1:
					rs=st.executeQuery("select contx_nm,data_lineage,kpi_defn,dflt_data_lineage_ind from t_KPI_data_lineage where kpi_ky=" + kpi_ky + " and srce_sys_nm='Vantage' and lang_cd='en_US'");
					break;
				case 2:
					rs=st.executeQuery("select contx_nm,data_lineage,kpi_defn,dflt_data_lineage_ind from t_KPI_data_lineage where kpi_ky=" + kpi_ky + " and srce_sys_nm='WFN' and lang_cd='en_US'");
					break;
				case 3:
					rs=st.executeQuery("select contx_nm,data_lineage,kpi_defn,dflt_data_lineage_ind from t_KPI_data_lineage where kpi_ky=" + kpi_ky + " and srce_sys_nm='EV5' and lang_cd='en_US'");
					break;
				case 4:
					rs=st.executeQuery("select contx_nm,data_lineage,kpi_defn,dflt_data_lineage_ind from t_KPI_data_lineage where kpi_ky=" + kpi_ky + " and srce_sys_nm='WFN' and lang_cd='fr_CA'");
					break;
				
				}
				
				while(rs.next()){
					resList1.add(new KPI_DataLineage(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
		            }
				rs.close();
		}catch(ClassNotFoundException e1){
			System.out.println(e1);
		}
		catch(SQLException e1){
			e1.printStackTrace();
		}
		finally{
			try{
				con.close();
			}catch(Exception e2){}
		}
		return resList1;
		
	}
	
	
	public List<KPI_Filters_Views> getFitersViews(int kpi_ky){
		Connection con=null;
		List<KPI_Filters_Views> resList2=new ArrayList();
		try{
			
			con=getConnection();
			Statement st=con.createStatement();
			
				ResultSet rs=st.executeQuery("select t_contx.contx_nm,t_contx.used_as_filt_ind,t_contx.used_as_view_by_ind,t_contx.contx_ky from t_kpi_alwbl_contx left outer join t_contx on t_kpi_alwbl_contx.contx_ky = t_contx.contx_ky where t_kpi_alwbl_contx.kpi_ky="+kpi_ky+" and t_contx.used_as_view_by_ind='Y'");
				while(rs.next()){
					resList2.add(new KPI_Filters_Views(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
						
		            }
				rs.close();
		}catch(ClassNotFoundException e1){
			System.out.println(e1);
		}
		catch(SQLException e1){
			e1.printStackTrace();
		}
		finally{
			try{
				con.close();
			}catch(Exception e2){}
		}
		return resList2;
		
	}
	
	
	public List<KPI_Default_ViewBy> getDefaultView(int kpi_ky){
		Connection con=null;
		List<KPI_Default_ViewBy> resList3=new ArrayList();
		try{
			
			con=getConnection();
			Statement st=con.createStatement();
			
				ResultSet rs=st.executeQuery("select view_by_default from t_kpi where kpi_ky="+kpi_ky);
				while(rs.next()){
					resList3.add(new KPI_Default_ViewBy(rs.getString(1)));
						
		            }
				rs.close();
		}catch(ClassNotFoundException e1){
			System.out.println(e1);
		}
		catch(SQLException e1){
			e1.printStackTrace();
		}
		finally{
			try{
				con.close();
			}catch(Exception e2){}
		}
		return resList3;
		
	}
	
	public List<String> excldViews(){
		Connection con=null;
		List<String> resList4=new ArrayList();
		try{
			
			con=getConnection();
			Statement st=con.createStatement();
			
				ResultSet rs=null;
				switch(domain){
				case 1:
					rs=st.executeQuery("select contx_ky_excluded from t_prdct where prod_nm='Vantage'");
					break;
				case 2:
					rs=st.executeQuery("select contx_ky_excluded from t_prdct where prod_nm='WFN'");
					break;
				case 3:
					rs=st.executeQuery("select contx_ky_excluded from t_prdct where prod_nm='EV5'");
					break;
				case 4:
					rs=st.executeQuery("select contx_ky_excluded from t_prdct where prod_nm='WFN'");
					break;
				}
				while(rs.next()){
					resList4.add(rs.getString(1));
						
		            }
				rs.close();
				
		}catch(ClassNotFoundException e1){
			System.out.println(e1);
		}
		catch(SQLException e1){
			e1.printStackTrace();
		}
		finally{
			try{
				con.close();
			}catch(Exception e2){}
		}
		return resList4;
	}
	
	public Connection getConnection() throws ClassNotFoundException,SQLException{
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//con=DriverManager.getConnection("jdbc:oracle:thin:HYRDSLVM0028.es.ad.adp.com:1521/cri02hyd", "ADPI_META_MODEL02", "fitmm390");
			con = DriverManager.getConnection("jdbc:oracle:thin:@HYRDSLVM0028.es.ad.adp.com:1521/cri02hyd",
					"ADPI_META_MODEL02", "fitmm390"); 
		}catch(ClassNotFoundException e){
			System.out.println(e);
			throw e;
		}
		catch(SQLException e1){
			e1.printStackTrace();
			throw e1;
		}
		
		return con;
	}
	
}

