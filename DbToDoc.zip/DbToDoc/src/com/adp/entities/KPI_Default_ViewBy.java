package com.adp.entities;

public class KPI_Default_ViewBy {

	private String default_view;

	public KPI_Default_ViewBy(String default_view) {
		super();
		this.default_view = default_view;
	}

	public String getDefault_view() {
		return default_view;
	}

	public void setDefault_view(String default_view) {
		this.default_view = default_view;
	}
}
