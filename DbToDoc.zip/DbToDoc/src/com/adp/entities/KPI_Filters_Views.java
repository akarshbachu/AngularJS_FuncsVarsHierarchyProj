package com.adp.entities;

public class KPI_Filters_Views {

	private String contx_nm;
	private String filter;
	private String viewBy;
	private String contx_ky;
	public KPI_Filters_Views(String contx_nm, String filter, String viewBy, String contx_ky) {
		super();
		this.contx_nm = contx_nm;
		this.filter = filter;
		this.viewBy = viewBy;
		this.contx_ky = contx_ky;
	}
	public String getContx_ky() {
		return contx_ky;
	}
	public void setContx_ky(String contx_ky) {
		this.contx_ky = contx_ky;
	}
	public KPI_Filters_Views(String contx_nm, String filter, String viewBy) {
		super();
		this.contx_nm = contx_nm;
		this.filter = filter;
		this.viewBy = viewBy;
	}
	public String getContx_nm() {
		return contx_nm;
	}
	public void setContx_nm(String contx_nm) {
		this.contx_nm = contx_nm;
	}
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
	public String getViewBy() {
		return viewBy;
	}
	public void setViewBy(String viewBy) {
		this.viewBy = viewBy;
	}
	
}
