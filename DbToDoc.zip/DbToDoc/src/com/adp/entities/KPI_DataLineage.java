package com.adp.entities;

public class KPI_DataLineage {
	private String contx_nm;
	private String data_lineage;
	private String kpi_defn;
	private String navigation;
	public KPI_DataLineage(String contx_nm, String data_lineage, String kpi_defn, String navigation) {
		super();
		this.contx_nm = contx_nm;
		this.data_lineage = data_lineage;
		this.kpi_defn = kpi_defn;
		this.navigation = navigation;
	}
	public String getNavigation() {
		return navigation;
	}
	public void setNavigation(String navigation) {
		this.navigation = navigation;
	}
	public KPI_DataLineage(String contx_nm, String data_lineage, String kpi_defn) {
		super();
		this.contx_nm = contx_nm;
		this.data_lineage = data_lineage;
		this.kpi_defn = kpi_defn;
	}
	public String getContx_nm() {
		return contx_nm;
	}
	public void setContx_nm(String contx_nm) {
		this.contx_nm = contx_nm;
	}
	public String getData_lineage() {
		return data_lineage;
	}
	public void setData_lineage(String data_lineage) {
		this.data_lineage = data_lineage;
	}
	public String getKpi_defn() {
		return kpi_defn;
	}
	public void setKpi_defn(String kpi_defn) {
		this.kpi_defn = kpi_defn;
	}

}
