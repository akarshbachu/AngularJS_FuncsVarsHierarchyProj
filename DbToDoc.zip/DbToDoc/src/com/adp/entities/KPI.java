package com.adp.entities;

public class KPI {

	private int kpi_ky;
	private String lang_cd;
	private String srce_sys_nm;
	private String kpi_nm;
	private String kpi_dsc;
	private String funcl_area;
	private String frmul_txt;
	private String bus_val;
	private String bus_rule;
	private String role_type;
	private String bnchmrks_appl;
	private String trshld_appl;
	private String rec_crt_ts;
	private int rec_crt_usr_ky;
	private String rec_lst_updt_ts;
	private int rec_lst_updt_usr_ky;
	public KPI(int kpi_ky, String lang_cd, String srce_sys_nm, String kpi_nm, String kpi_dsc, String funcl_area,
			String frmul_txt, String bus_val, String bus_rule, String role_type, String bnchmrks_appl,
			String trshld_appl, String rec_crt_ts, int rec_crt_usr_ky, String rec_lst_updt_ts,
			int rec_lst_updt_usr_ky) {
		super();
		this.kpi_ky = kpi_ky;
		this.lang_cd = lang_cd;
		this.srce_sys_nm = srce_sys_nm;
		this.kpi_nm = kpi_nm;
		this.kpi_dsc = kpi_dsc;
		this.funcl_area = funcl_area;
		this.frmul_txt = frmul_txt;
		this.bus_val = bus_val;
		this.bus_rule = bus_rule;
		this.role_type = role_type;
		this.bnchmrks_appl = bnchmrks_appl;
		this.trshld_appl = trshld_appl;
		this.rec_crt_ts = rec_crt_ts;
		this.rec_crt_usr_ky = rec_crt_usr_ky;
		this.rec_lst_updt_ts = rec_lst_updt_ts;
		this.rec_lst_updt_usr_ky = rec_lst_updt_usr_ky;
	}
	public int getKpi_ky() {
		return kpi_ky;
	}
	public void setKpi_ky(int kpi_ky) {
		this.kpi_ky = kpi_ky;
	}
	public String getLang_cd() {
		return lang_cd;
	}
	public void setLang_cd(String lang_cd) {
		this.lang_cd = lang_cd;
	}
	public String getSrce_sys_nm() {
		return srce_sys_nm;
	}
	public void setSrce_sys_nm(String srce_sys_nm) {
		this.srce_sys_nm = srce_sys_nm;
	}
	public String getKpi_nm() {
		return kpi_nm;
	}
	public void setKpi_nm(String kpi_nm) {
		this.kpi_nm = kpi_nm;
	}
	public String getKpi_dsc() {
		return kpi_dsc;
	}
	public void setKpi_dsc(String kpi_dsc) {
		this.kpi_dsc = kpi_dsc;
	}
	public String getFuncl_area() {
		return funcl_area;
	}
	public void setFuncl_area(String funcl_area) {
		this.funcl_area = funcl_area;
	}
	public String getFrmul_txt() {
		return frmul_txt;
	}
	public void setFrmul_txt(String frmul_txt) {
		this.frmul_txt = frmul_txt;
	}
	public String getBus_val() {
		return bus_val;
	}
	public void setBus_val(String bus_val) {
		this.bus_val = bus_val;
	}
	public String getBus_rule() {
		return bus_rule;
	}
	public void setBus_rule(String bus_rule) {
		this.bus_rule = bus_rule;
	}
	public String getRole_type() {
		return role_type;
	}
	public void setRole_type(String role_type) {
		this.role_type = role_type;
	}
	public String getBnchmrks_appl() {
		return bnchmrks_appl;
	}
	public void setBnchmrks_appl(String bnchmrks_appl) {
		this.bnchmrks_appl = bnchmrks_appl;
	}
	public String getTrshld_appl() {
		return trshld_appl;
	}
	public void setTrshld_appl(String trshld_appl) {
		this.trshld_appl = trshld_appl;
	}
	public String getRec_crt_ts() {
		return rec_crt_ts;
	}
	public void setRec_crt_ts(String rec_crt_ts) {
		this.rec_crt_ts = rec_crt_ts;
	}
	public int getRec_crt_usr_ky() {
		return rec_crt_usr_ky;
	}
	public void setRec_crt_usr_ky(int rec_crt_usr_ky) {
		this.rec_crt_usr_ky = rec_crt_usr_ky;
	}
	public String getRec_lst_updt_ts() {
		return rec_lst_updt_ts;
	}
	public void setRec_lst_updt_ts(String rec_lst_updt_ts) {
		this.rec_lst_updt_ts = rec_lst_updt_ts;
	}
	public int getRec_lst_updt_usr_ky() {
		return rec_lst_updt_usr_ky;
	}
	public void setRec_lst_updt_usr_ky(int rec_lst_updt_usr_ky) {
		this.rec_lst_updt_usr_ky = rec_lst_updt_usr_ky;
	}
	
}
