import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTP;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTSectPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTText;

import com.adp.dao.jdbc;
import com.adp.entities.KPI;
import com.adp.entities.KPI_DataLineage;
import com.adp.entities.KPI_Default_ViewBy;
import com.adp.entities.KPI_Filters_Views;

public class Test2 {

	public static XWPFRun run1=null;
	public static int j=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			FileReader reader=new FileReader("C:\\Users\\BachuAka\\workspace\\DbToDoc\\metricInfo_fr.properties");  
			FileReader reader1=new FileReader("C:\\Users\\BachuAka\\workspace\\DbToDoc\\headings.properties");
			
		    Properties p=new Properties();  
		    p.load(reader);  
		    
		    Properties p1=new Properties();  
		    p1.load(reader1); 
		   
		   /* String s="context.31.name";
			System.out.println(p.getProperty(s));*/
			
			XWPFDocument document =new XWPFDocument();
			CTSectPr sectPr = document.getDocument().getBody().addNewSectPr();
			XWPFHeaderFooterPolicy policy = new XWPFHeaderFooterPolicy(document, sectPr);
			
			FileOutputStream out=null;
			
			
			Scanner sc=new Scanner(System.in);
			System.out.println("1.Vantage 2.WFN 3.EV5 4.WFN_CA");
			int src=sc.nextInt();
			
			switch(src){
			case 1: 
				out=new FileOutputStream(new File("C:\\Users\\BachuAka\\Desktop\\Vantage.docx"));
				break;
			case 2: 
				out=new FileOutputStream(new File("C:\\Users\\BachuAka\\Desktop\\WFN.docx"));
				break;
			case 3:
				out=new FileOutputStream(new File("C:\\Users\\BachuAka\\Desktop\\EV5.docx"));
				break;
			case 4:
				out=new FileOutputStream(new File("C:\\Users\\BachuAka\\Desktop\\WFN_CA.docx"));
				break;
			}
			
			List<KPI> res=new jdbc().getData(src);
			List<String> excldViews=new jdbc().excldViews();
			String ev[]=excldViews.get(0).split(",");
			List<String> ev1=Arrays.asList(ev);
			System.out.println(ev1.size());
			System.out.println(excldViews);
			
			List<String> headings=new ArrayList();
			if(src!=4){
			
			headings.add("Functional Area");
			headings.add("Role");
			headings.add("Description");
			headings.add("Business Value");
			headings.add("Business Rule");
			headings.add("Views");
			headings.add("Benchmark Applicable");
			headings.add("Thresholds");
			headings.add("Navigation");
			headings.add("Formula");
			headings.add("Metrics Large Card View");
			}
			else{
				headings.add(p1.getProperty("ADPA_LBL_IBUTTON_FUNCTIONAL_AREA"));
				headings.add(p1.getProperty("ADPA_LBL_IBUTTON_ROLE"));
				headings.add(p1.getProperty("ADPA_LBL_DESCRIPTION"));
				headings.add(p1.getProperty("ADPA_LBL_IBUTTON_BUSINESS_VALUE"));
				headings.add(p1.getProperty("ADPA_LBL_IBUTTON_BUSINESS_RULE"));
				headings.add("Vues");
				headings.add(p1.getProperty("ADPA_LBL_BENCHMARK_APPLICABLE"));
				headings.add(p1.getProperty("ADPA_LBL_THRESHOLDS"));
				headings.add(p1.getProperty("ADPA_LBL_NAVIGATION"));
				headings.add(p1.getProperty("ADPA_LBL_IBUTTON_FORUMULA"));
				headings.add("Metrics Large Card Voir");
			}
			XWPFRun run2=null;
			for(int k=0;k<res.size();k++){
				//KPI name
				
				XWPFParagraph paragraph2=document.createParagraph();
				run2=paragraph2.createRun();
				
				XWPFParagraph paragraph1=document.createParagraph();
				run1=paragraph1.createRun();
				run1.setText(res.get(k).getKpi_nm());
				run1.setBold(true);
				run1.setColor("2980b9");
				run1.setFontSize(20);
				
				XWPFTable table=document.createTable();
				XWPFTableRow row=table.getRow(0);
				XWPFTableCell cell=row.getCell(0);
				XWPFParagraph paragraph=cell.addParagraph();
				paragraph.setIndentationLeft(50);
				XWPFRun r=paragraph.createRun();
				r.setText(headings.get(0));
				r.setBold(true);
			
				XWPFTableCell cell1=row.addNewTableCell();
				XWPFParagraph paragraph12=cell1.addParagraph();
				paragraph12.setIndentationLeft(50);
				XWPFRun rr=paragraph12.createRun();
				rr.setText(res.get(k).getFuncl_area());
				
				
				XWPFTableRow row2=table.createRow();
				XWPFRun r2 = setRowPara(row2);
				r2.setText(headings.get(1));
				r2.setBold(true);
				
				XWPFRun r3 = setRowPara(row2);
				r3.setText(res.get(k).getRole_type());
				j=0;
				setRowColor(row2);
				
				
				XWPFTableRow row3=table.createRow();
				XWPFRun r4 = setRowPara(row3);
				r4.setText(headings.get(2));
				r4.setBold(true);
				
				XWPFRun r5 = setRowPara(row3);
				r5.setText(res.get(k).getKpi_dsc().replaceAll("<br>"," "));
				j=0;
				
				
				XWPFTableRow row10=table.createRow();
				XWPFRun r18 = setRowPara(row10);
				r18.setText(headings.get(9));
				r18.setBold(true);
				
				XWPFRun r19 = setRowPara(row10);
				r19.setText(res.get(k).getFrmul_txt()!=null ? res.get(k).getFrmul_txt().replaceAll("<br>"," "):" ");
				j=0;
				setRowColor(row10);
				
				XWPFTableRow row4=table.createRow();
				XWPFRun r6 = setRowPara(row4);
				r6.setText(headings.get(3));
				r6.setBold(true);
				
				XWPFRun r7 = setRowPara(row4);
				r7.setText(res.get(k).getBus_val().replaceAll("<br>"," "));
				j=0;
				//setRowColor(row4);
				
				
				XWPFTableRow row5=table.createRow();
				XWPFRun r8 = setRowPara(row5);
				r8.setText(headings.get(4));
				r8.setBold(true);
				
				XWPFRun r9 = setRowPara(row5);
				r9.setText((res.get(k).getBus_rule())!=null ? res.get(k).getBus_rule().replaceAll("<br>"," "):
					"");
				j=0;
				setRowColor(row5);
				
				List<KPI_Filters_Views> filterViewBy=new jdbc().getFitersViews(res.get(k).getKpi_ky());
				String viewDefault="";
				try{
				List<KPI_Default_ViewBy> defaultView=new jdbc().getDefaultView(res.get(k).getKpi_ky());
				
					if(defaultView!=null){
						viewDefault=defaultView.get(0).getDefault_view();
						//System.out.println(viewDefault);
					}
				}catch(Exception e){
					
				}
				if(filterViewBy!=null && viewDefault!=null){	

					XWPFTableRow row6=table.createRow();
					XWPFRun r10 = setRowPara(row6);
					r10.setText(headings.get(5));
					r10.setBold(true);
					
					XWPFRun r25=setRowPara(row6);
					String viewDf="";
					try{
						if(viewDefault!=null && viewDefault!="" && viewDefault!=" "){
						viewDf=viewDefault.replaceAll("VIEW_BY_","").toLowerCase();
						viewDf=viewDf.substring(0,1).toUpperCase()+viewDf.substring(1);
						viewDf=viewDf.replaceAll("_", " ");
						//System.out.println(viewDf);
						if(src==4)
							r25.setText("D�faut: "+viewDf);
						else
							r25.setText("Default: "+viewDf);
						j=1;
						
						}
						
						int count=0;
						for(int i=0;i<filterViewBy.size();i++){
							
							if((!ev1.contains(filterViewBy.get(i).getContx_ky())) ){
								
								if(filterViewBy.get(i).getContx_nm().equalsIgnoreCase(viewDf)){
									//System.out.println(viewDf);
								}
								else{		
									if(count==0){
										XWPFRun r26=setRowPara(row6);
										if(src==4)
											r26.setText("Autres vues:");
										else
											r26.setText("Other Views:");
										j=1;
									}
									XWPFRun r11 = setRowPara(row6);
									if(src==4){
										
										r11.setText(p.getProperty("context."+filterViewBy.get(i).getContx_ky()+".name"));
										r11.getParagraph().setIndentationLeft(300);
										j=1;
										count++;
									}
									else{
										if(filterViewBy.get(i).getContx_nm().equals("View By EEO1") && (src==2 || src==4))
										r11.setText("EEOC Job Classification");
										
										else
											r11.setText(filterViewBy.get(i).getContx_nm().replaceAll("View By ", ""));
										r11.getParagraph().setIndentationLeft(300);
										j=1;
										count++;
									}
									}
							}	
						}
						count=0;
					j=0;	
					}catch(Exception e){
						System.out.println(e.getMessage()+" Hello");
					}
				}
				XWPFTableRow row8=table.createRow();
				XWPFRun r14 = setRowPara(row8);
				r14.setText(headings.get(7));
				r14.setBold(true);
				
				XWPFRun r15 = setRowPara(row8);
				r15.setText(res.get(k).getTrshld_appl());
				j=0;
				setRowColor(row8);
				
				
				XWPFTableRow row7=table.createRow();
				XWPFRun r12 = setRowPara(row7);
				r12.setText(headings.get(6));
				r12.setBold(true);
				
				XWPFRun r13 = setRowPara(row7);
				if(src==4)
					r13.setText((res.get(k).getBnchmrks_appl()).length()>3 ? "Oui" :"Non");
				else
					r13.setText((res.get(k).getBnchmrks_appl()).length()>2 ? "Yes" :"No");
				j=0;
				
				
				
				
				XWPFTableRow row11=table.createRow();
				XWPFRun r20 = setRowPara(row11);
				r20.setText(headings.get(10));
				r20.setBold(true);
				
				XWPFRun r21 = setRowPara(row8);
				r21.setText("");
				j=0;
				setRowColor(row11);
				
				List<KPI_DataLineage> nav=new jdbc().getDataLineage(res.get(k).getKpi_ky());
				for(int i=0;i<nav.size();i++){
					if(nav.get(i).getNavigation().equals("Y")){
						XWPFTableRow row9=table.createRow();
						XWPFRun r16 = setRowPara(row9);
						r16.setText(headings.get(8));
						r16.setBold(true);
						
						XWPFRun r17 = setRowPara(row9);
						r17.setText((nav.get(i).getData_lineage())!=null ? nav.get(i).getData_lineage().replaceAll("<br>", " "):"");
						j=0;
					}
				}
				
				if(k!=0)
				run2.addBreak(BreakType.PAGE);
			}
			
			CTP ctpFooter = CTP.Factory.newInstance();
			CTR ctrFooter = ctpFooter.addNewR();
			CTText ctFooter = ctrFooter.addNewT();
			String footerText="";
			if(src==4)
				footerText="ADP et ADP logo sont des marques d�pos�es d'ADP, LLC. ADP-A plus de ressources humaines. est une marque de service d'ADP, LLC. Droit d'auteur � 2017ADP, LLC. adp.com";
			else
				footerText = "ADP and ADP logo are registered trademarks of ADP,LLC. ADP-A more human resource. is a service mark of ADP,LLC. Copyright � 2017ADP,LLC.  adp.com";
			ctFooter.setStringValue(footerText);	
			XWPFParagraph footerParagraph = new XWPFParagraph(ctpFooter, document);
			footerParagraph.createRun().setFontSize(6);
			
		        XWPFParagraph[] parsFooter = new XWPFParagraph[1];
		        parsFooter[0] = footerParagraph;
			policy.createFooter(XWPFHeaderFooterPolicy.DEFAULT, parsFooter);
			
			
			document.write(out);
			
			out.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		System.out.println("Success");

	}
	
	public static void setRowColor(XWPFTableRow row){
		for(int i=0;i<2;i++){
			row.getCell(i).setColor("ecf0f1");
		}
	}
	
	public static XWPFRun setRowPara(XWPFTableRow row){
		XWPFTableCell cell=row.getCell(j++);
		XWPFParagraph paragraph=cell.addParagraph();
		
		paragraph.setIndentationLeft(50);
		XWPFRun r=paragraph.createRun();
		return r;
	}
}
