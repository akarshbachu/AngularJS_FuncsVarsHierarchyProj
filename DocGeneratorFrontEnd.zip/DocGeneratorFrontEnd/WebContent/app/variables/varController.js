﻿var app = angular.module('myApp');
app.controller('varController', ['$state','$getObjService', function ($state,$getObjService) {
   
   var vCtrl=this;
   vCtrl.i = 0;
   vCtrl.list = $getObjService.objs;
   vCtrl.redirectTo = function (pos, vName) {
      
       vName = vCtrl.list[pos].variableName;
       $state.go('variable',{i:pos,j:vName})
    }
    
   
}])

//app.run(function ($rootScope, $log, $state) {
//    $rootScope.$on("$stateChangeStart", function () {
//        $log.info("*********changing**********");
//    })
//    $rootScope.$on("$stateChangeSuccess", function (e, toState, toParams, fromState, fromParams) {
//        $log.info('Routing to next Route...' + " from state: " + fromState.name + " to state: " + toState.name);
//        if (toState.name === "variables") {
//            $log.info("Condition staisfied");
//        }
//    })
//})