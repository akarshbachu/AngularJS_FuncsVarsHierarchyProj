﻿var app = angular.module('myApp');
app.component('listComponent', 
    
        {
            templateUrl: 'http://localhost:2426/DocGeneratorFrontEnd/templates/listDisplay.html',
            binding: {
                list: '<',
                redirectTo: '&'
            },
            controller: 'commonController',
            controllerAs:'cCtrl'
        
        
    }
)