﻿var app = angular.module('myApp');
app.controller('funcsFormController', function ($getObjService, $filter, $state,$http,$scope) {
    var funcFormCtrl = this;
    funcFormCtrl.ldData = function () {
        funcFormCtrl.lst2 = $getObjService.flist;

        //filtering duplicates
        funcFormCtrl.liOfModules = funcFormCtrl.lst2.filter(function (value, index) { return funcFormCtrl.lst2.indexOf(value) == index });
        console.log(funcFormCtrl.liOfModules);
    }

    funcFormCtrl.submitData = function () {
        console.log("loading data to file");
        console.log($scope.options);
        $http.post('http://localhost:2426/DocGenerator/rest/function/save', {
            "functionName": $scope.functionName,
            "module": $scope.options,
            "purpose": $scope.purpose,
            "isUsedInUI": "yes",
            "getsCalledIn": ["x", "z","asd"]
        }).then(function (response) {
            funcFormCtrl.status = response.status;
            console.log(funcFormCtrl.status)
           // $scope.entryCount = response.data;
        }, function (response) {
           // $scope.entryCount = response.data || 'Request failed';
            funcFormCtrl.status = response.status;
            console.log(funcFormCtrl.status)
        });
    }
})