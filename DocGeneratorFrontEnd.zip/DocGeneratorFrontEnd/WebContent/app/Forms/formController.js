﻿var app = angular.module('myApp');
app.controller('formController', function ($state) {
    var frmCtrl = this;
    frmCtrl.goToVarsForm = function () {
        $state.go('varsForm');
    }
    frmCtrl.goToFuncsForm = function () {
        $state.go('funcsForm');
    }
});