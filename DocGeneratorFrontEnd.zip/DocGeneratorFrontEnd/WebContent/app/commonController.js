﻿var app = angular.module('myApp');
var values;
app.controller('commonController', ['$state','$getObjService', '$location', function ($state,$getObjService, $location) {
    var url = $location.absUrl();
    var res = url.substring(url.length - 9, url.length);
    var cCtrl = this;

    cCtrl.$onInit = function () {
        if(res=='variables')
        {
            cCtrl.list = $getObjService.objs;
        }
        else {
            cCtrl.list = $getObjService.objs2;
        }
    }

    if (res == 'variables') {
        console.log($getObjService.loadJson+"-------");
        cCtrl.loadData = function () {
                values = { "name": "variables", "children": $getObjService.treeCompatibleJson("variableName") };

                cCtrl.data = values;
        }
        cCtrl.redirectTo = function (pos, vName) {
            vName = cCtrl.list[pos].variableName;
            $state.go('variable', { i: pos, j: vName })
        }
    }
    else {
        cCtrl.loadData = function () {
                values = { "name": "functions", "children": $getObjService.treeCompatibleJson("functionName") };
                cCtrl.data = values;
        }

        cCtrl.redirectTo = function (pos, vName) {
            vName = cCtrl.list[pos].functionName;
            $state.go('function', { i: pos, j: vName })
        }
    }

}]);





